	<div class="container">
	  <!-- FOOTER -->
	  <footer>
	    <p class="pull-right"><a href="#">DEVIN PS</a></p>
	    <p>© 2018</p>
	  </footer>

	</div><!-- /.container -->
</body>
</html>